INSERT INTO planets (id, name, climate, terrain) VALUES (1, 'Tatooine', 'arid', 'desert');
INSERT INTO planets (id, name, climate, terrain) VALUES (2, 'Alderaan', 'temperate', 'grasslands, mountains');
INSERT INTO planets (id, name, climate, terrain) VALUES (3, 'Yavin IV', 'temperate, tropical', 'jungle, rainforests');