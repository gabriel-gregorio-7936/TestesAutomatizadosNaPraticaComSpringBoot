package com.example.swplanetapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwPlanetApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwPlanetApiApplication.class, args);
	}

}
